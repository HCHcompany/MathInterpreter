// <unistd.h> GCC header simplified, basically everything removed

#ifndef _UNISTD_H
#define _UNISTD_H 1

extern int usleep(int usec);

extern int sleep(unsigned int seconds);

#endif /* unistd.h  */
