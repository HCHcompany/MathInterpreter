// <stdbool.h> GCC header simplified 
// Defines booleans

#ifndef _STDBOOL_H
#define _STDBOOL_H

typedef char	bool;

#define true	1
#define false	0

#endif
