
int main() {
    return 0 + 1 * 2;
}