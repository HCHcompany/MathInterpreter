// sizeof operator

int main() {
    return sizeof(char) + sizeof(short) + sizeof(short int) + sizeof(int) + sizeof(long) +
           sizeof(long int) + sizeof(int*) + sizeof(float) + sizeof(double);
}