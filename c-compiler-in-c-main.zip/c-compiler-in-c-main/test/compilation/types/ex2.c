// Test for stack alignment

int main() {
    unsigned char x1 = 1;
    short x2 = 2;
    short int x3 = 3;
    int x4 = 4;
    long x5 = 5;
    long int x6 = 6;
    float x7 = 7;
    double x8 = 8;
    x1 += 320;
    return x1;
}