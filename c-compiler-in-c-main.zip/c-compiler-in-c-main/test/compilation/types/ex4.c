// Implicit casting

int main() {
    double z = 1.5;
    double y = (double) 1;
    double x = 1.5 + 3;
    double w = 4;
    char c = 'h';
    return (int) z + (int) y + w + x + c;
}