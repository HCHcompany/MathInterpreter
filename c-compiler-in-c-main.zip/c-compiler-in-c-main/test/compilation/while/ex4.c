// Do while one-line

int main() {
    int x = 5;
    do
        x = x + 5;
    while (x < 100);
    do
        ;
    while (0);
    return x;
}