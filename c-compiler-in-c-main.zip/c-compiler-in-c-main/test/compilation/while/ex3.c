// Do while loop

int main() {
    int y = 0;
    int x = 4;
    do {
        x--;
        y++;
    } while (x > 0);
    do {
        y++;
    } while (x == 100);
    return y;
}