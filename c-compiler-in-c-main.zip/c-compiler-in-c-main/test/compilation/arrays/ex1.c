

int main() {
    int x[40];
    x[0] = 1;
    x[3] = 10;
    return x[0] + x[3];
}