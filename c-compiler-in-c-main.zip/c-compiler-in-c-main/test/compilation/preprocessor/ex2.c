// Pragma once test
#include "include3.h"
#include "include3.h"
#include "include4.h"

int main() {
    return test3() + test4();
}