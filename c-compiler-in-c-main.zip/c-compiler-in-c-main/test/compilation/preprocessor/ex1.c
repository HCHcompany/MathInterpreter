// Normal includes
#include "include1.h"

int main() {
    return test1() + test2();
}