// Define replace macros

#define INTERESTING

#define VAL 1

#define cool return VAL;

int main() {
    cool return VAL + 1 INTERESTING;
}