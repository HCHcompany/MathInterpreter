#pragma once
#include "include3.h"

int test4() {
    return 4;
}