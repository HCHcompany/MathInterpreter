// Include guard test

#include "include2.h"
#include "include2.h"

int main() {
    return test2();
}