#pragma once

int test3() {
    return 3;
}