#include <stdio.h>
#include <stddef.h>

int main() {
    printf("Standard library include test!");
    putchar(10);
    return NULL;
}