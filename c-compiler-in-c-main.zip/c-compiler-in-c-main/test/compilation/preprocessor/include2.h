#ifndef INCLUDE2
#define INCLUDE2

int test2() {
    return 2;
}

#endif