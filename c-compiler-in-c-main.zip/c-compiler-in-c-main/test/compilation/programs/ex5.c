// Assert teset
#include <assert.h>
#include <stdbool.h>

int main() {
    assert(true);
}