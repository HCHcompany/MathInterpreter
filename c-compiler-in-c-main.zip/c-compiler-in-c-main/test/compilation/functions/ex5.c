// Function parameters

int add(int a, int b) {
    return a + b;
}

int main() {
    return add(3, 7);
}