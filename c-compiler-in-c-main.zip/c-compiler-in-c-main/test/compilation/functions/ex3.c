
int test() {
    int x = 1;
    int z = 3;
    return x;
}

int main() {
    int x = test();
    return x;
}