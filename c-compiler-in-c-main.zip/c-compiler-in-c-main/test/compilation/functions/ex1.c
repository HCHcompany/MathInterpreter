// Just tests that the assembly generates correctly for two function definition

int test() {
    return 1;
}

int main() {
    return 0;
}