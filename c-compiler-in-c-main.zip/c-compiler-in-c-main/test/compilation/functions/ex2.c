// Test simple function

void test2() {
    return;
}

int test1() {
    return 1;
}

int main() {
    test2();
    return test1();
}