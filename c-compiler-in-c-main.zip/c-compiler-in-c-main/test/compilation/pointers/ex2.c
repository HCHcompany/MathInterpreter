// Char pointers
void printf(char* str);

int main() {
    char* str = "Hello world!\n";
    printf(str);
    return *str;
}