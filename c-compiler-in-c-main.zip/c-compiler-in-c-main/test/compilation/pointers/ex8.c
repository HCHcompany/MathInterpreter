int main() {
    char* ptr = "hello";
    int b = 1;
    if (ptr && b) {
        return 1;
    }
    return 0;
}