// Multiple variable definitions using comma

int main() {
    int x, y;
    long z, w, u;
    x = 1;
    y = 2;
    z = 3;
    w = 4;
    u = 5;
    return x + y + z + w + u;
}
