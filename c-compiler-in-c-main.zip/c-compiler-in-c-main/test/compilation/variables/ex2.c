// Declare a variable and assign in same statement

int main() {
    int x = 4;
    return x;
}