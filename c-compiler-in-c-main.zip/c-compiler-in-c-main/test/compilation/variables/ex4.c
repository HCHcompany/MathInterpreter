// Scopes

int main() {
    int x = 4;
    int y = x;
    return y;
}