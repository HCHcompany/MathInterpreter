// Declare a variable, assign to it, return it

int main() {
    int x;
    x = 5;
    x = 4;
    return x;
}