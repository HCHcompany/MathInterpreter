// More compilcated declaration and assignments

int main() {
    int y;
    int x = 4;
    y = 3;
    x = 2;
    int z = 1;
    return y;
}