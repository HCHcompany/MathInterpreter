// Global variables

int x = 4;
int y = 2;
int z;
int w;
w = 5;

const int a = 10;

int main() {
    z = 10;
    x++;
    return x + y + w + z + a;
}