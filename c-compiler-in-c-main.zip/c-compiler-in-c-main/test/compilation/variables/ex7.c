// Floating point globals

float f = 1.5;

int main() {
    return (int) f;
}