// Single statement if, else

int main() {
    int x = 4;
    if (x > 4)
        return 1;
    else
        return 2;
    return 3;
}
