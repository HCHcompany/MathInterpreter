// If else

int main() {
    int x = 4;
    if (x == 4) {
        if (x != 4) {
            return 1;
        }
        else {
            return 2;
        }
    }
    else {
        return 3;
    }
    return 4;
}