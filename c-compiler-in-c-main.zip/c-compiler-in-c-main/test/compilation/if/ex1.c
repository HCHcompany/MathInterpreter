// Simple if

int main() {
    int x = 1;
    if (x) {
        return 0;
    }
    return 1;
}