// Most basic program

int main() {
    return 0;
}