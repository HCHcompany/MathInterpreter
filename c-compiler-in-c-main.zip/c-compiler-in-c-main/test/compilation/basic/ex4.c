// Null expression

int main() {
    ;
    return 0;
}