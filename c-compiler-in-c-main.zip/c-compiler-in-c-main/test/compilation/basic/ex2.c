// Most basic program with a non-zero return

int main() {
    return 5;
}