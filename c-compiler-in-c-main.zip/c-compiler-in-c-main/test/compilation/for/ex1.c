// Basic for loop

int main() {
    int y = 0;
    for (int i = 0; i < 10; i++) {
        y = y + 3;
    }
    return y;
}