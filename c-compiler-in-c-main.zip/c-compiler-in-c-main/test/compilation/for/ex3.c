// Single line for loop

int main() {
    int x = 0;
    for (int i = 0; i < 10; i = i + 1)
        x++;
    return x;
}