// Empty statement for loop

int main() {
    int i = 0;
    for (; i < 11;) {
        i++;
    }
    return i;
}