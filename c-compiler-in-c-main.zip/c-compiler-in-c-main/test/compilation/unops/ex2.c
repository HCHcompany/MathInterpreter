// Simple logical not

int main() {
    int y = 4;
    int x = !y;
    return x;
}