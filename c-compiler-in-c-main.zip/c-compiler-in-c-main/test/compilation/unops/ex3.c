// Combination of operators

int main() {
    return ~!!!~-1;
}