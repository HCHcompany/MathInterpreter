// Simple negation

int main() {
    return -1;
}