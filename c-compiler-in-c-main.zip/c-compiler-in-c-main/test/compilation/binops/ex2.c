// Multiple binary ops and a unary op

int main() {
    return 1 + 2 + 3 + -3;
}