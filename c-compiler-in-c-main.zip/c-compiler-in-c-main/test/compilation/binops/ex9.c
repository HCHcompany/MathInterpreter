// Parenthesis

int main() {
    return (5 - 2) - 3;
}