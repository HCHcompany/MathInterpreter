// Floating point operations

int main() {
    double z = 3.4;
    z += 4.5;
    z -= 3.0;
    z *= 5.3;
    z /= 0.4;
    return (int) ((-1.0 + 3.5 - 1.3333 * 3.14 + 4) / 0.01) + z;
}