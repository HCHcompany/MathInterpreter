// Not equals

int main() {
    int x = 7 != 6;
    int y = 7 != 7;
    return x + y;
}