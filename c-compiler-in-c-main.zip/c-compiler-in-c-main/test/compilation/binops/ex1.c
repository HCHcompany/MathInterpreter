// Simple test

int main() {
    return 1 + 2;
}