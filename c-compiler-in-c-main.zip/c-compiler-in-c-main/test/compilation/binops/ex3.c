// Subtraction

int main() {
    int x1 = 10 - 3;
    int x2 = 9 * 7;
    int x3 = 200 / 7;
    int x4 = 101 % 7;
    return x1 + x2 + x3 + x4;
}