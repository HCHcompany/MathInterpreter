// Precedence test

int main() {
    return (1 + 3 * 4 / 3 == 1 + 10) * 5 + 3 % 4 * 4 - 1 + -1;
}