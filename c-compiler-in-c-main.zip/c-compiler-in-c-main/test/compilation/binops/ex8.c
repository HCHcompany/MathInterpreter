// Assigment as binary operator

int main() {
    int x;
    if (x = 1) {
        return 1;
    }
    return 0;
}