// Advanced parenthesis

int main() {
    int y = 3;
    int x = 2;
    int z = ((5));
    return ((16 - 4) / (z - x)) - (1 - (x + y)); // 4 - (-4)
}